# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['governor']

package_data = \
{'': ['*'], 'governor': ['templates/*']}

install_requires = \
['Flask>=2.2.2,<3.0.0',
 'absl-py>=1.3.0,<2.0.0',
 'aiohttp>=3.8.3,<4.0.0',
 'requests>=2.28.1,<3.0.0',
 'torch>=1.13.0,<2.0.0']

setup_kwargs = {
    'name': 'governor',
    'version': '0.1.0',
    'description': '',
    'long_description': '# Governor\n\n## Protobuf\n\n```bash\nprotoc -I ./ --go_out=api/ --go_opt=paths=import --go_opt=module=github.com/kevmo314/fedtorch/governor/api api/*proto\n```\n',
    'author': 'Kevin Wang',
    'author_email': 'kevmo314@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
