# Governor

## Protobuf

```bash
protoc -I ./ --go_out=api/ --go_opt=paths=import --go_opt=module=github.com/kevmo314/fedtorch/governor/api api/*proto
```
